import { createFileRoute, Link } from "@tanstack/react-router";
import { motion, useReducedMotion, useScroll, useTransform } from "motion/react";
import { useRef, useState } from "react";
import { products } from "@/lib/products";
import { FrameCard } from "@/components/site/FrameCard";
import { Reveal, StaggerGroup, StaggerItem } from "@/components/site/Reveal";
import { TouchlineDivider } from "@/components/site/TouchlineDivider";

export const Route = createFileRoute("/")({
  component: Index,
});

const ease = [0.22, 1, 0.36, 1] as const;

function Hero() {
  const reduce = useReducedMotion();
  const ref = useRef<HTMLElement>(null);
  const { scrollYProgress } = useScroll({ target: ref, offset: ["start start", "end start"] });
  const yStrip = useTransform(scrollYProgress, [0, 1], [0, reduce ? 0 : -70]);
  const opacity = useTransform(scrollYProgress, [0, 0.8], [1, 0.25]);

  return (
    <header
      ref={ref}
      className="grain relative overflow-hidden pb-10 pt-32 sm:pt-40"
      style={{ background: "var(--gradient-hero)" }}
    >
      <motion.div style={{ opacity }} className="mx-auto max-w-4xl px-6 text-center">
        <motion.p
          initial={reduce ? false : { opacity: 0, y: 16 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, ease }}
          className="kicker"
        >
          Designed &amp; shipped from the US · Damaged prints replaced free
        </motion.p>
        <motion.h1
          initial={reduce ? false : { opacity: 0, y: 26 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.75, delay: 0.12, ease }}
          className="heading-display mt-6 text-[2.6rem] leading-[1.04] sm:text-6xl md:text-7xl"
        >
          Iconic soccer jerseys, transformed into{" "}
          <span className="relative inline-block whitespace-nowrap text-primary">
            wall art
            <svg
              viewBox="0 0 200 20"
              preserveAspectRatio="none"
              className="absolute -bottom-2 left-0 h-3 w-full overflow-visible"
              aria-hidden="true"
            >
              <path d="M4 12 C 40 7, 90 16, 130 10 S 180 9, 196 13" className="chalk-path" />
            </svg>
          </span>
          .
        </motion.h1>
        <motion.p
          initial={reduce ? false : { opacity: 0, y: 22 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.7, delay: 0.28, ease }}
          className="mx-auto mt-6 max-w-xl text-lg leading-relaxed text-muted-foreground"
        >
          Collector-style framed prints of football's greatest shirts, each one carrying the stats,
          honours and words of a career.
        </motion.p>
        <motion.ul
          initial={reduce ? false : { opacity: 0, y: 18 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.7, delay: 0.4, ease }}
          className="mt-7 flex flex-wrap justify-center gap-2.5"
          aria-label="Key facts"
        >
          {["$34.99 per print", "8.5 × 11 in · arrives framed", "Free US shipping · 5–8 days", "Damaged prints replaced free"].map(
            (chip) => (
              <li
                key={chip}
                className="rounded-full border border-border bg-card/60 px-4 py-1.5 font-mono text-xs text-foreground"
              >
                {chip}
              </li>
            ),
          )}
        </motion.ul>
        <motion.div
          initial={reduce ? false : { opacity: 0, y: 18 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.7, delay: 0.52, ease }}
          className="mt-9 flex flex-wrap items-center justify-center gap-3"
        >
          <a
            href="#collection"
            onClick={(e) => {
              e.preventDefault();
              document.getElementById("collection")?.scrollIntoView({ behavior: "smooth" });
            }}
            className="rounded-md bg-primary px-7 py-3.5 text-base font-semibold text-primary-foreground shadow-lg shadow-primary/20 transition-all hover:brightness-110 active:scale-[0.98]"
          >
            Browse the collection →
          </a>
          <Link
            to="/custom"
            className="rounded-md border border-border px-7 py-3.5 text-base font-semibold transition-colors hover:border-primary hover:text-primary"
          >
            Request a custom print
          </Link>
        </motion.div>
      </motion.div>

      {/* Kit-strip marquee with parallax */}
      <motion.div
        style={{ y: yStrip }}
        initial={reduce ? false : { opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ duration: 1, delay: 0.7 }}
        className="mt-16 overflow-hidden"
        aria-hidden="true"
      >
        <div className="animate-marquee flex w-max gap-5 px-5">
          {[...products, ...products, ...products].map((p, i) => (
            <span
              key={`${p.id}-${i}`}
              className="block w-28 shrink-0 overflow-hidden rounded-md border border-border shadow-lg sm:w-36"
              style={{ rotate: `${((i % 5) - 2) * 1.3}deg` }}
            >
              <img src={p.swatchImg} alt="" loading="lazy" className="block h-full w-full object-cover" />
            </span>
          ))}
        </div>
      </motion.div>
    </header>
  );
}

function Collection() {
  return (
    <section id="collection" className="mx-auto max-w-6xl scroll-mt-24 px-6 pt-6">
      <Reveal className="mx-auto max-w-2xl text-center">
        <p className="kicker">The Gallery Wall</p>
        <h2 className="heading-display mt-4 text-4xl sm:text-5xl">The Legends Series</h2>
        <p className="mt-5 leading-relaxed text-muted-foreground">
          Seven shirts, seven stories. Each piece carries the shirt, the stats, the honours and the
          player's own words in one composition — printed edge-to-edge in deep, saturated colour
          and delivered already framed, ready to hang straight out of the box.
        </p>
      </Reveal>
      <StaggerGroup className="mt-14 grid gap-x-8 gap-y-16 sm:grid-cols-2 lg:grid-cols-3">
        {products.map((p, i) => (
          <FrameCard key={p.id} product={p} index={i} />
        ))}
        <StaggerItem className="flex flex-col">
          <div className="print-frame">
            <div className="print-matte">
              <div className="flex aspect-[880/1151] flex-col items-center justify-center gap-3 bg-pitch p-6 text-center">
                <h3 className="heading-display text-2xl text-chalk">
                  More legends
                  <br />
                  coming soon
                </h3>
                <p className="text-sm text-muted-foreground">New shirts join the wall every season.</p>
                <a href="#join" className="font-mono text-xs uppercase tracking-widest text-primary underline-offset-4 hover:underline">
                  Join the club list →
                </a>
              </div>
            </div>
          </div>
        </StaggerItem>
      </StaggerGroup>
    </section>
  );
}

function HowItWorks() {
  const steps = [
    {
      n: "01",
      t: "Pick your legend",
      d: "Choose from the Legends Series, or commission any player, club and era as a custom print.",
    },
    {
      n: "02",
      t: "Made for you, by hand",
      d: "Each piece is designed, printed and framed one at a time. Nothing prints until your order is confirmed.",
    },
    {
      n: "03",
      t: "On your wall in days",
      d: "Free US shipping, arriving framed and ready to hang in 5–8 business days. Damaged prints replaced free.",
    },
  ];
  return (
    <section className="mx-auto max-w-6xl px-6">
      <Reveal className="text-center">
        <p className="kicker">From Kickoff to Wall</p>
        <h2 className="heading-display mt-4 text-4xl sm:text-5xl">How it works</h2>
      </Reveal>
      <StaggerGroup className="mt-12 grid gap-6 md:grid-cols-3">
        {steps.map((s) => (
          <StaggerItem key={s.n}>
            <div className="h-full rounded-lg border border-border bg-card p-7 transition-colors hover:border-primary/50">
              <span className="font-mono text-sm text-brass-bright">{s.n}</span>
              <h3 className="heading-display mt-3 text-xl">{s.t}</h3>
              <p className="mt-3 text-sm leading-relaxed text-muted-foreground">{s.d}</p>
            </div>
          </StaggerItem>
        ))}
      </StaggerGroup>
    </section>
  );
}

function Guarantees() {
  const items = [
    { t: "Damaged prints replaced free", d: "If it arrives less than perfect, a replacement ships at no cost. No forms, no fuss." },
    { t: "Nothing prints until you confirm", d: "Every order gets a personal reply before production starts, so what arrives is exactly what you wanted." },
    { t: "A real person on every order", d: "One-person shop. The person who designs your print is the same one who answers your email." },
  ];
  return (
    <section className="border-y border-border bg-pitch">
      <div className="mx-auto max-w-6xl px-6 py-16">
        <StaggerGroup className="grid gap-10 md:grid-cols-3">
          {items.map((g) => (
            <StaggerItem key={g.t}>
              <div className="flex gap-4">
                <svg className="mt-1 h-6 w-6 shrink-0 text-primary" fill="none" stroke="currentColor" strokeWidth="1.8" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" d="M9 12.75L11.25 15 15 9.75M21 12c0 1.268-.63 2.39-1.593 3.068a3.745 3.745 0 01-1.043 3.296 3.745 3.745 0 01-3.296 1.043A3.745 3.745 0 0112 21c-1.268 0-2.39-.63-3.068-1.593a3.746 3.746 0 01-3.296-1.043 3.745 3.745 0 01-1.043-3.296A3.745 3.745 0 013 12c0-1.268.63-2.39 1.593-3.068a3.745 3.745 0 011.043-3.296 3.746 3.746 0 013.296-1.043A3.746 3.746 0 0112 3c1.268 0 2.39.63 3.068 1.593a3.746 3.746 0 013.296 1.043 3.746 3.746 0 011.043 3.296A3.745 3.745 0 0121 12z" />
                </svg>
                <div>
                  <h3 className="font-semibold">{g.t}</h3>
                  <p className="mt-1.5 text-sm leading-relaxed text-muted-foreground">{g.d}</p>
                </div>
              </div>
            </StaggerItem>
          ))}
        </StaggerGroup>
      </div>
    </section>
  );
}

function Story() {
  return (
    <section id="story" className="mx-auto max-w-3xl scroll-mt-24 px-6 text-center">
      <Reveal>
        <p className="kicker">Our Story</p>
        <h2 className="heading-display mt-4 text-4xl sm:text-5xl">A fan behind the touchline</h2>
        <p className="mt-6 leading-relaxed text-muted-foreground">
          Touchline Prints is a one-person shop, and that one person is a fan first. This started as
          prints for my own wall: the shirts that meant something to me, with the whole career
          underneath them — the numbers, the silverware and the player's own words in one piece.
          Friends wanted them. Then strangers did.
        </p>
        <p className="mt-4 leading-relaxed text-muted-foreground">
          Every order is still made the same way. I design each composition from scratch, print it,
          frame it and pack it by hand, one at a time, and I read every message that comes in. Old
          fan or new fan — if a number ever meant something to you, there's a place on your wall for
          it.
        </p>
      </Reveal>
    </section>
  );
}

function CustomCTA() {
  return (
    <section className="mx-auto max-w-6xl px-6">
      <Reveal>
        <div className="grain relative overflow-hidden rounded-xl border border-border bg-card px-8 py-14 text-center sm:px-14">
          <div
            className="pointer-events-none absolute inset-0"
            style={{
              background:
                "radial-gradient(ellipse 70% 90% at 50% 110%, oklch(0.63 0.135 152 / 14%), transparent 65%)",
            }}
          />
          <p className="kicker relative">Custom Orders</p>
          <h2 className="heading-display relative mt-4 text-3xl sm:text-4xl">
            Your club. Your player. Your moment.
          </h2>
          <p className="relative mx-auto mt-4 max-w-xl leading-relaxed text-muted-foreground">
            Any shirt that ever meant something to you, designed in the Touchline style with a free
            mock-up before anything prints.
          </p>
          <Link
            to="/custom"
            className="relative mt-8 inline-block rounded-md bg-primary px-7 py-3.5 text-base font-semibold text-primary-foreground shadow-lg shadow-primary/20 transition-all hover:brightness-110 active:scale-[0.98]"
          >
            Start a custom order →
          </Link>
        </div>
      </Reveal>
    </section>
  );
}

function ClubList() {
  const [email, setEmail] = useState("");
  const [status, setStatus] = useState("");
  return (
    <section id="join" className="mx-auto max-w-2xl scroll-mt-24 px-6 pb-24 text-center">
      <Reveal>
        <p className="kicker">The Club List</p>
        <h2 className="heading-display mt-4 text-4xl sm:text-5xl">New legends every season</h2>
        <p className="mt-4 leading-relaxed text-muted-foreground">
          Join the club list to hear about new drops first.
        </p>
        <form
          className="mx-auto mt-7 flex max-w-md flex-col gap-3 sm:flex-row"
          onSubmit={(e) => {
            e.preventDefault();
            if (!email) return;
            window.location.href = `mailto:touchlineprints@gmail.com?subject=${encodeURIComponent(
              "Join the club list",
            )}&body=${encodeURIComponent(`Please add ${email} to the Touchline Prints club list.`)}`;
            setStatus("Your email app should open — hit send and you're on the list.");
          }}
        >
          <label htmlFor="club-email" className="sr-only">
            Email address
          </label>
          <input
            id="club-email"
            type="email"
            required
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            placeholder="your@email.com"
            autoComplete="email"
            className="flex-1 rounded-md border border-input bg-card px-4 py-3 text-sm outline-none transition-colors placeholder:text-muted-foreground focus:border-primary"
          />
          <button
            type="submit"
            className="rounded-md bg-primary px-6 py-3 text-sm font-semibold text-primary-foreground transition-all hover:brightness-110 active:scale-[0.98]"
          >
            Join the club list
          </button>
        </form>
        {status && (
          <p role="status" aria-live="polite" className="mt-4 text-sm text-primary">
            {status}
          </p>
        )}
      </Reveal>
    </section>
  );
}

function Index() {
  return (
    <main>
      <Hero />
      <TouchlineDivider />
      <Collection />
      <TouchlineDivider flip />
      <HowItWorks />
      <div className="h-16" />
      <Guarantees />
      <div className="h-20" />
      <Story />
      <TouchlineDivider />
      <CustomCTA />
      <div className="h-20" />
      <ClubList />
    </main>
  );
}
